"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { RecurringPlanCard } from "@/components/portal/RecurringPlanCard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Progress } from "@/components/ui/progress";
import {
  RiUserLine, RiBankCardLine, RiCalendarLine, RiLoader4Line,
  RiCheckboxCircleFill, RiLockLine, RiTimeLine, RiMapPinLine, RiBox3Line,
  RiAlertLine, RiHomeLine, RiCloseLine, RiArrowDownSLine, RiArrowUpSLine,
  RiStarLine, RiSparklingLine, RiArrowRightLine, RiSettings3Line, RiNotification3Line,
  RiGiftLine, RiShieldCheckLine, RiCoupon3Line, RiExternalLinkLine, RiStarFill
} from "@remixicon/react";
import { ReferralSection } from "@/components/ReferralSection";
import { CreditWallet } from "@/components/CreditWallet";
import { toast } from "sonner";
import { format, isPast, isFuture, differenceInDays, differenceInHours } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { RescheduleDialog } from "@/components/booking/RescheduleDialog";
import { ModifyBookingDialog } from "@/components/booking/ModifyBookingDialog";
import { RatingDialog } from "@/components/booking/RatingDialog";
import { CancelBookingDialog } from "@/components/booking/CancelBookingDialog";
import { cn } from "@/lib/utils";
import { SEO } from "@/components/SEO";
import { Panel } from "@/components/ui/panel";
import { parseServiceDate } from "@/lib/service-date";

// Signed-in customers book in-app at /portal/book (credits, saved addresses,
// preferred cleaner, or pay for an extra clean). The public funnel on the
// try.* subdomain is only for logged-out visitors.

interface Booking {
  id: string;
  service_date: string;
  time_slot: string;
  service_type: string;
  status: string;
  address: string;
  city: string;
  state: string;
  zip_code: string;
  total_estimate_cents: number;
  uses_credit: boolean;
  home_size_id: string;
  service_duration?: number;
  add_ons: string[];
  bedrooms: number | null;
  bathrooms: number | null;
  dwelling_type: string | null;
  membership_plan: string;
  rating_submitted: boolean;
  cleaner_id: string | null;
  created_at: string;
  booking_channel?: string | null;
}

interface MembershipCredit {
  membership_plan: string;
  credits_per_month: number;
  credits_remaining: number;
  credits_used: number;
  current_period_start: string;
  current_period_end: string;
}

export default function Account() {
  const router = useRouter();
  const { user, subscription, checkSubscription, openCustomerPortal, resetPassword } = useAuth();
  const [isResettingPassword, setIsResettingPassword] = useState(false);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [membershipCredits, setMembershipCredits] = useState<MembershipCredit | null>(null);
  const [isLoadingBookings, setIsLoadingBookings] = useState(true);
  const [rescheduleBooking, setRescheduleBooking] = useState<Booking | null>(null);
  const [rescheduleDialogOpen, setRescheduleDialogOpen] = useState(false);
  const [modifyBooking, setModifyBooking] = useState<Booking | null>(null);
  const [modifyDialogOpen, setModifyDialogOpen] = useState(false);
  const [ratingBooking, setRatingBooking] = useState<Booking | null>(null);
  const [ratingDialogOpen, setRatingDialogOpen] = useState(false);
  const [cancelBookingItem, setCancelBookingItem] = useState<Booking | null>(null);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [pastBookingsOpen, setPastBookingsOpen] = useState(false);

  useEffect(() => {
    if (!user) {
      router.push("/auth");
    } else {
      checkSubscription();
      fetchBookings();
      fetchMembershipCredits();
    }
  }, [user, router]);

  const fetchBookings = async () => {
    if (!user?.email) return;
    setIsLoadingBookings(true);
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('email', user.email)
        .order('service_date', { ascending: false });
      if (error) throw error;
      setBookings(data || []);
    } catch (error: any) {
      console.error('Error fetching bookings:', error);
      toast.error('Failed to load booking history');
    } finally {
      setIsLoadingBookings(false);
    }
  };

  const fetchMembershipCredits = async () => {
    if (!user?.email) return;
    try {
      const { data, error } = await supabase
        .from('membership_credits')
        .select('*')
        .eq('email', user.email)
        .maybeSingle();
      if (error) throw error;
      setMembershipCredits(data);
    } catch (error: any) {
      console.error('Error fetching membership credits:', error);
    }
  };

  // Signed-in customers always book in-app at /portal/book (credits / saved
  // addresses / preferred cleaner / extra paid cleans). We no longer gate on
  // the async `subscription` flag — it can briefly report not-subscribed and
  // wrongly bounce members to the public funnel on try.*.
  const handleBookNow = () => {
    router.push("/portal/book");
  };

  // Resume an unfinished booking. Portal (in-app) bookings that still owe a
  // card re-open the hosted Checkout; funnel bookings hand off to try.* with
  // an absolute URL so the cross-subdomain redirect can't strand the user.
  const handleCompleteBooking = async (booking: Booking) => {
    if (booking.status === "pending_details") {
      window.location.href = `https://try.novaracleaning.com/book/details?booking_id=${booking.id}`;
      return;
    }
    if (booking.booking_channel === "portal") {
      try {
        const { data, error } = await supabase.functions.invoke("portal-book-checkout", {
          body: { action: "create", bookingId: booking.id },
        });
        if (error || (data as any)?.error || !(data as any)?.url) {
          throw new Error((data as any)?.error || "Could not resume payment");
        }
        window.location.href = (data as any).url as string;
      } catch (e: any) {
        toast.error(e?.message || "Could not resume payment");
      }
      return;
    }
    window.location.href = `https://try.novaracleaning.com/book/checkout?booking_id=${booking.id}`;
  };

  const handleManageSubscription = async () => {
    // Note: we DON'T pre-gate on `subscription?.hasCustomer` anymore.
    // The customer-portal Edge Function auto-creates a Stripe customer
    // when none exists, so a user who has never booked can still click
    // through to the Billing Portal to add a card. The previous gate
    // was the root cause of "can't access payment portal" reports from
    // brand-new accounts.
    try {
      await openCustomerPortal();
    } catch (error: any) {
      const errorMessage = error.message || "Failed to open customer portal";
      toast.error(errorMessage);
    }
  };

  const handleChangePassword = async () => {
    if (!user?.email) return;
    setIsResettingPassword(true);
    const { error } = await resetPassword(user.email);
    if (error) {
      toast.error(error.message || "Failed to send reset email");
    } else {
      toast.success("Password reset link sent to your email!");
    }
    setIsResettingPassword(false);
  };

  const handleReschedule = (booking: Booking) => {
    setRescheduleBooking(booking);
    setRescheduleDialogOpen(true);
  };

  const handleRescheduleSuccess = () => {
    fetchBookings();
    fetchMembershipCredits();
  };

  const handleModify = (booking: Booking) => {
    setModifyBooking(booking);
    setModifyDialogOpen(true);
  };

  const handleModifySuccess = () => {
    fetchBookings();
    fetchMembershipCredits();
  };

  const handleRating = (booking: Booking) => {
    setRatingBooking(booking);
    setRatingDialogOpen(true);
  };

  const handleRatingSubmitted = () => {
    setRatingDialogOpen(false);
    setRatingBooking(null);
    fetchBookings();
  };

  const handleCancel = (booking: Booking) => {
    setCancelBookingItem(booking);
    setCancelDialogOpen(true);
  };

  const handleCancelSuccess = () => {
    fetchBookings();
    fetchMembershipCredits();
  };

  const getStatusConfig = (status: string) => {
    const configs: Record<string, { color: string; bg: string; label: string; dot: string }> = {
      confirmed: { color: "text-emerald-700 dark:text-emerald-400", bg: "bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800", label: "Confirmed", dot: "bg-emerald-500" },
      pending_payment: { color: "text-amber-700 dark:text-amber-400", bg: "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800", label: "Pending Payment", dot: "bg-amber-500" },
      // pending_details — payment cleared but the home-detail step was
      // skipped. The booking is NOT confirmed yet (no dispatch, no
      // confirmation email). Surface it just like pending_payment so the
      // customer is nudged back into /book/details to finish the job.
      pending_details: { color: "text-amber-700 dark:text-amber-400", bg: "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800", label: "Details Needed", dot: "bg-amber-500" },
      cancelled: { color: "text-red-600 dark:text-red-400", bg: "bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800", label: "Cancelled", dot: "bg-red-500" },
      completed: { color: "text-primary", bg: "bg-primary/5 border-primary/20", label: "Completed", dot: "bg-primary" },
    };
    return configs[status] || { color: "text-muted-foreground", bg: "bg-muted border-border", label: status, dot: "bg-muted-foreground" };
  };

  const getCountdown = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const days = differenceInDays(date, now);
    if (days > 1) return `${days} days away`;
    const hours = differenceInHours(date, now);
    if (hours > 0) return `${hours}h away`;
    return "Today";
  };

  // "assigned" is still an upcoming appointment — cancel must stay available
  // after a cleaner is dispatched (matches SMS cancel + cancel-booking).
  const upcomingBookings = bookings.filter(b =>
    isFuture(parseServiceDate(b.service_date)) &&
    (b.status === "confirmed" || b.status === "assigned")
  );
  const nextBooking = upcomingBookings.length > 0 ? upcomingBookings[upcomingBookings.length - 1] : null;
  const otherUpcoming = upcomingBookings.filter(b => b.id !== nextBooking?.id);
  const pastBookings = bookings.filter(b =>
    (isPast(parseServiceDate(b.service_date)) || b.status === 'completed' || b.status === 'cancelled') && b.status !== 'pending_payment'
  );
  // Surface bookings that paid but never finished the home-detail step
  // (pending_details) as well as bookings that never finished payment
  // (pending_payment). The dashboard "Complete Your Booking" hero turns
  // into a one-tap path back into /book/details when the customer has
  // already paid but skipped the property questionnaire.
  const incompleteBookings = bookings
    .filter(b => {
      if (b.status !== 'pending_payment' && b.status !== 'pending_details') return false;
      const bookingCreatedAt = new Date(b.created_at);
      const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      return bookingCreatedAt > sevenDaysAgo;
    })
    .slice(0, 1);

  const userName = user?.user_metadata?.full_name
    || user?.email?.split('@')[0]?.replace(/[._]/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
    || 'there';
  const userInitials = userName.split(' ').map((n: string) => n[0]).join('').toUpperCase().slice(0, 2);

  if (!user) {
    return (
      <div className="flex items-center justify-center py-24">
        <RiLoader4Line className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const creditProgress = membershipCredits
    ? Math.round((membershipCredits.credits_used / membershipCredits.credits_per_month) * 100)
    : 0;

  return (
    <div className="mx-auto max-w-5xl space-y-5 md:space-y-6">
      <SEO title="My Account" description="Manage your bookings, membership credits, and account settings. View upcoming and past cleanings." noindex />
      <Panel className="p-5 md:p-6">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 md:gap-4 min-w-0">
            <div className="w-12 h-12 md:w-14 md:h-14 rounded-2xl flex items-center justify-center text-primary-foreground font-bold text-lg shadow-[0_8px_20px_-8px_rgba(92,15,254,0.55)]" style={{ background: "var(--gradient-primary)" }}>
              {userInitials}
            </div>
            <div className="min-w-0">
              <h1 className="font-heading text-lg md:text-xl font-bold tracking-tight">
                Welcome back, {userName.split(" ")[0]}
              </h1>
              <p className="text-xs md:text-sm text-muted-foreground truncate">{user.email}</p>
            </div>
          </div>
          <Button size="sm" onClick={handleBookNow}>
            <RiCalendarLine size={16} className="md:mr-1.5" />
            <span className="hidden md:inline">Book now</span>
          </Button>
        </div>
      </Panel>

      <div className="space-y-5 md:space-y-6">

        {/* Incomplete Booking Alert */}
        {incompleteBookings.length > 0 && (
          <div className="animate-fade-in-up">
            {incompleteBookings.map(booking => {
              // pending_details = paid but the home-detail questionnaire
              // is missing → push the customer back into /book/details
              // (the booking can't be confirmed without it).
              // pending_payment = payment never cleared → /book/checkout
              // remains the right next step.
              const isDetailsStep = booking.status === 'pending_details';
              const ctaLabel = isDetailsStep ? 'Complete Details' : 'Complete Payment';
              const headerLine = isDetailsStep
                ? 'Finish Your Booking Details'
                : 'Complete Your Booking';
              const subLine = isDetailsStep
                ? 'Payment received — share your home details so we can confirm and dispatch your cleaner.'
                : `${format(parseServiceDate(booking.service_date), 'MMMM d')} · ${booking.service_type} · $${(booking.total_estimate_cents / 100).toFixed(2)}`;
              return (
                <Card key={booking.id} className="border-amber-300 dark:border-amber-700 bg-amber-50/60 dark:bg-amber-950/20 shadow-md">
                  <CardContent className="p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-900/40 flex items-center justify-center flex-shrink-0">
                          <RiAlertLine className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                        </div>
                        <div>
                          <p className="font-semibold text-sm">{headerLine}</p>
                          <p className="text-xs text-muted-foreground">{subLine}</p>
                        </div>
                      </div>
                      <div className="flex gap-2 w-full sm:w-auto">
                        <Button size="sm" className="flex-1 sm:flex-none bg-amber-600 hover:bg-amber-700 text-white shadow-sm"
                          onClick={() => handleCompleteBooking(booking)}>
                          {ctaLabel} <RiArrowRightLine className="w-3.5 h-3.5 ml-1.5" />
                        </Button>
                        <Button size="sm" variant="ghost" className="text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                          onClick={() => handleCancel(booking)}>
                          <RiCloseLine className="w-4 h-4" />
                          <span className="sr-only">Discard incomplete booking</span>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Next Booking Hero */}
        {nextBooking ? (
          <Card className="animate-fade-in-up overflow-hidden shadow-lg border-0">
            <div className="h-1 w-full" style={{ background: 'var(--gradient-primary)' }} />
            <CardContent className="p-5 md:p-7">
              <div className="flex items-start justify-between mb-5">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-[0.12em] text-primary">Next Cleaning</span>
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  </div>
                  <h2 className="text-2xl md:text-3xl font-bold tracking-tight">
                    {format(parseServiceDate(nextBooking.service_date), "EEEE, MMMM d")}
                  </h2>
                  <p className="text-muted-foreground mt-0.5 flex items-center gap-1.5">
                    <RiTimeLine className="w-3.5 h-3.5" />
                    {nextBooking.time_slot}
                  </p>
                </div>
                <Badge className="text-xs font-semibold bg-primary/10 text-primary border-primary/20 px-3 py-1.5">
                  {getCountdown(nextBooking.service_date)}
                </Badge>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-muted/40 dark:bg-muted/20 mb-5">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <RiMapPinLine className="w-4 h-4 text-primary" />
                  </div>
                  <div className="text-sm min-w-0">
                    <p className="font-medium truncate">{nextBooking.address}</p>
                    <p className="text-muted-foreground text-xs">{nextBooking.city}, {nextBooking.state}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <RiSparklingLine className="w-4 h-4 text-primary" />
                  </div>
                  <div className="text-sm">
                    <p className="font-medium">{nextBooking.service_type}</p>
                    <p className="text-muted-foreground text-xs">{nextBooking.home_size_id}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <RiBankCardLine className="w-4 h-4 text-primary" />
                  </div>
                  <div className="text-sm">
                    <p className="font-semibold text-primary">${(nextBooking.total_estimate_cents / 100).toFixed(2)}</p>
                    {nextBooking.uses_credit && <p className="text-muted-foreground text-xs">Using credit</p>}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" className="h-9 rounded-lg" onClick={() => handleModify(nextBooking)}>
                  <RiSettings3Line className="w-3.5 h-3.5 mr-1.5" /> Modify
                </Button>
                <Button variant="outline" size="sm" className="h-9 rounded-lg" onClick={() => handleReschedule(nextBooking)}>
                  <RiCalendarLine className="w-3.5 h-3.5 mr-1.5" /> Reschedule
                </Button>
                <Button variant="ghost" size="sm" className="h-9 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10" onClick={() => handleCancel(nextBooking)}>
                  <RiCloseLine className="w-3.5 h-3.5 mr-1.5" /> Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="animate-fade-in-up border-dashed border-2 border-border/60">
            <CardContent className="py-12 md:py-16 text-center">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
                <RiCalendarLine className="w-8 h-8 text-primary/60" />
              </div>
              <h2 className="text-xl font-bold mb-1.5">No upcoming cleanings</h2>
              <p className="text-sm text-muted-foreground mb-5 max-w-xs mx-auto">
                Schedule your next professional cleaning and let us handle the rest.
              </p>
              <Button onClick={handleBookNow} className="bg-gradient-primary shadow-md h-11 px-6">
                <RiSparklingLine className="w-4 h-4 mr-2" /> Book a Cleaning
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Membership + Account Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5">
          {/* Recurring plan management (renders only for recurring members) */}
          <RecurringPlanCard />

          {/* Membership Credits Card */}
          {membershipCredits ? (
            <Card className="animate-fade-in-up stagger-1 shadow-md border-primary/15 overflow-hidden">
              <div className="h-0.5 w-full" style={{ background: 'var(--gradient-primary)' }} />
              <CardContent className="p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: 'var(--gradient-primary)' }}>
                      <RiCoupon3Line className="w-4.5 h-4.5 text-white" />
                    </div>
                    <div>
                      <span className="font-semibold text-sm">
                        {membershipCredits.membership_plan.charAt(0).toUpperCase() + membershipCredits.membership_plan.slice(1)} Plan
                      </span>
                      <p className="text-[11px] text-muted-foreground">Renews {format(new Date(membershipCredits.current_period_end), "MMM d")}</p>
                    </div>
                  </div>
                  <Badge className="bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800 text-xs">Active</Badge>
                </div>

                <div className="mb-4">
                  <div className="flex items-end justify-between mb-2">
                    <div>
                      <span className="text-3xl font-bold text-primary">{membershipCredits.credits_remaining}</span>
                      <span className="text-sm text-muted-foreground ml-1">/ {membershipCredits.credits_per_month}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">{membershipCredits.credits_used} used this cycle</span>
                  </div>
                  <Progress value={creditProgress} className="h-2" />
                </div>

                {membershipCredits.credits_remaining > 0 && (
                  <Button className="w-full h-10 bg-gradient-primary shadow-sm" onClick={() => router.push("/portal/book")}>
                    <RiCalendarLine className="w-4 h-4 mr-2" /> Use Credit to Book
                  </Button>
                )}
                {/* Glow members manage their card / billing cycle /
                    pause-resume / cancel inside the same Stripe Customer
                    Portal that one-time customers use to update their
                    card. One link, both flows covered. */}
                <Button
                  variant="outline"
                  className="w-full h-10 mt-2 rounded-lg"
                  onClick={handleManageSubscription}
                >
                  <RiBankCardLine className="w-4 h-4 mr-2 text-primary" />
                  Manage Subscription & Card
                </Button>
              </CardContent>
            </Card>
          ) : (
            <Card className="animate-fade-in-up stagger-1 border-dashed border-2 border-primary/20">
              <CardContent className="p-5 flex flex-col items-center justify-center text-center h-full min-h-[200px]">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                  <RiGiftLine className="w-6 h-6 text-primary" />
                </div>
                <p className="font-semibold mb-1">Save with a Membership</p>
                <p className="text-xs text-muted-foreground mb-4 max-w-[200px]">Get monthly credits and save up to 30% on every clean</p>
                <Button variant="outline" size="sm" onClick={() => router.push("/membership")} className="rounded-lg">
                  View Plans <RiArrowRightLine className="w-3.5 h-3.5 ml-1.5" />
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Account & Quick Actions */}
          <Card id="settings" className="animate-fade-in-up stagger-2 shadow-md scroll-mt-20">
            <CardContent className="p-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                  <RiUserLine className="w-5 h-5 text-foreground" />
                </div>
                <div>
                  <p className="font-semibold text-sm">Account Settings</p>
                  <p className="text-xs text-muted-foreground truncate max-w-[180px]">{user.email}</p>
                </div>
              </div>
              <Separator className="mb-4" />
              <div className="grid grid-cols-2 gap-2.5">
                <Button variant="outline" size="sm" className="justify-start text-xs h-10 rounded-lg"
                  onClick={handleBookNow}>
                  <RiCalendarLine className="w-4 h-4 mr-2 text-primary" /> Book Cleaning
                </Button>
                {/* Billing / payment-method update — always show so
                    customers can update their card even without an
                    active membership. The Stripe Customer Portal also
                    handles subscription management for Glow members
                    from the same screen. */}
                <Button variant="outline" size="sm" className="justify-start text-xs h-10 rounded-lg"
                  onClick={handleManageSubscription}>
                  <RiBankCardLine className="w-4 h-4 mr-2 text-primary" />
                  {subscription?.subscribed ? "Billing & Card" : "Payment Method"}
                </Button>
                <Button variant="outline" size="sm" className="justify-start text-xs h-10 rounded-lg"
                  onClick={handleChangePassword} disabled={isResettingPassword}>
                  <RiLockLine className="w-4 h-4 mr-2 text-primary" /> {isResettingPassword ? "Sending..." : "Password"}
                </Button>
                <Button variant="outline" size="sm" className="justify-start text-xs h-10 rounded-lg"
                  onClick={() => router.push("/membership")}>
                  <RiBox3Line className="w-4 h-4 mr-2 text-primary" /> Membership
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Referral */}
        <div className="animate-fade-in-up stagger-3 space-y-4">
          {user?.email && <CreditWallet email={user.email} />}
          {user?.email && <ReferralSection email={user.email} />}
        </div>

        {/* Other Upcoming Bookings */}
        {otherUpcoming.length > 0 && (
          <div className="space-y-3 animate-fade-in-up stagger-4">
            <h3 className="text-xs font-bold text-muted-foreground uppercase tracking-[0.1em] px-1">
              Upcoming ({otherUpcoming.length})
            </h3>
            <div className="space-y-2.5">
              {otherUpcoming.map(booking => {
                const sc = getStatusConfig(booking.status);
                return (
                  <Card key={booking.id} className="shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-4">
                          <div className="text-center min-w-[48px] py-2 px-3 rounded-xl bg-primary/5">
                            <p className="text-[10px] uppercase tracking-wider font-semibold text-primary">{format(parseServiceDate(booking.service_date), 'MMM')}</p>
                            <p className="text-xl font-bold leading-tight">{format(parseServiceDate(booking.service_date), 'd')}</p>
                          </div>
                          <div>
                            <p className="font-medium text-sm">{booking.time_slot} &middot; {booking.service_type}</p>
                            <p className="text-xs text-muted-foreground">{booking.address}, {booking.city}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 pl-16 sm:pl-0">
                          <span className="font-semibold text-sm">${(booking.total_estimate_cents / 100).toFixed(2)}</span>
                          <Button variant="outline" size="sm" className="text-xs h-8 rounded-lg" onClick={() => handleReschedule(booking)}>Reschedule</Button>
                          <Button variant="ghost" size="sm" className="text-xs h-8 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10" onClick={() => handleCancel(booking)}>Cancel</Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        )}

        {/* Past Bookings */}
        {pastBookings.length > 0 && (
          <Collapsible open={pastBookingsOpen} onOpenChange={setPastBookingsOpen}>
            <CollapsibleTrigger asChild>
              <button className="w-full flex items-center justify-between py-3 px-1 text-muted-foreground hover:text-foreground transition-colors group">
                <span className="text-xs font-bold uppercase tracking-[0.1em]">
                  Past Bookings ({pastBookings.length})
                </span>
                <RiArrowDownSLine className={cn("w-4 h-4 transition-transform duration-200", pastBookingsOpen && "rotate-180")} />
              </button>
            </CollapsibleTrigger>
            <CollapsibleContent className="space-y-2 mt-1">
              {pastBookings.map(booking => {
                const sc = getStatusConfig(booking.status);
                return (
                  <Card key={booking.id} className="bg-muted/20 border-border/60 shadow-none">
                    <CardContent className="p-3.5">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="text-center min-w-[40px]">
                            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">{format(parseServiceDate(booking.service_date), 'MMM')}</p>
                            <p className="text-base font-bold leading-tight">{format(parseServiceDate(booking.service_date), 'd')}</p>
                          </div>
                          <div className="min-w-0">
                            <p className="font-medium text-sm truncate">{booking.service_type} &middot; {booking.home_size_id}</p>
                            <p className="text-xs text-muted-foreground truncate">{booking.city}, {booking.state}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <div className="flex items-center gap-1.5">
                            <div className={cn("w-1.5 h-1.5 rounded-full", sc.dot)} />
                            <span className={cn("text-xs font-medium", sc.color)}>{sc.label}</span>
                          </div>
                          <span className="text-sm font-medium ml-1">${(booking.total_estimate_cents / 100).toFixed(2)}</span>
                          {booking.status === "completed" && booking.cleaner_id && !booking.rating_submitted && (
                            <Button size="sm" variant="outline" className="text-xs h-7 rounded-lg ml-1" onClick={() => handleRating(booking)}>
                              <RiStarLine className="w-3 h-3 mr-1" /> Rate
                            </Button>
                          )}
                          {booking.rating_submitted && (
                            <Badge variant="secondary" className="text-[10px] h-6"><RiStarFill className="w-3 h-3 text-amber-500" /> Rated</Badge>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </CollapsibleContent>
          </Collapsible>
        )}

        {/* Loading state for bookings */}
        {isLoadingBookings && bookings.length === 0 && (
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <RiLoader4Line className="w-6 h-6 animate-spin text-primary mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">Loading your bookings...</p>
            </div>
          </div>
        )}
      </div>

      {/* Dialogs */}
      {rescheduleBooking && (
        <RescheduleDialog
          open={rescheduleDialogOpen}
          onOpenChange={setRescheduleDialogOpen}
          booking={rescheduleBooking}
          onSuccess={handleRescheduleSuccess}
        />
      )}
      {modifyBooking && (
        <ModifyBookingDialog
          open={modifyDialogOpen}
          onOpenChange={setModifyDialogOpen}
          booking={modifyBooking}
          onSuccess={handleModifySuccess}
        />
      )}
      {ratingBooking && (
        <RatingDialog
          open={ratingDialogOpen}
          onOpenChange={setRatingDialogOpen}
          bookingId={ratingBooking.id}
          cleanerName="Your Cleaner"
          onRatingSubmitted={handleRatingSubmitted}
        />
      )}
      {cancelBookingItem && (
        <CancelBookingDialog
          open={cancelDialogOpen}
          onOpenChange={setCancelDialogOpen}
          booking={cancelBookingItem}
          onSuccess={handleCancelSuccess}
        />
      )}
    </div>
  );
}
