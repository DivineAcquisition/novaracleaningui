"use client";
import {
  RiArrowRightLine,
  RiCheckboxCircleLine,
  RiGiftLine,
  RiMapPinLine,
  RiTimeLine,
  RiVipCrownLine
} from "@remixicon/react";
import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useBooking } from "@/contexts/BookingContext";

import { BookingHeader } from "@/components/booking/BookingHeader";
import { BookingFooter } from "@/components/booking/BookingFooter";
import { ZipGallery } from "@/components/booking/ZipGallery";
import { supabase } from "@/integrations/supabase/client";
import { formatPhoneNumber } from "@/lib/input-formatters";
import { trackLead } from "@/lib/meta-pixel";
import { SEO } from "@/components/SEO";
import { getStoredTrackingData, getTrackingPayload } from "@/hooks/useUTMTracking";

type FormMode = 'zip' | 'contact' | 'waitlist' | 'waitlist-success';

export default function BookingZip() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { updateBookingData } = useBooking();
  const referralCode = searchParams.get('ref');
  const fbclid = searchParams.get('fbclid');
  const membershipParam = searchParams.get('membership');
  const homeSizeParam = searchParams.get('homeSize');
  const welcomeCode = searchParams.get('welcome');

  // Capture referral code from URL on mount
  useEffect(() => {
    if (referralCode) {
      updateBookingData({ referralCode: referralCode.toUpperCase() });
    }
  }, [referralCode]);

  // Glow plan pages hand off into this same funnel so membership signup
  // uses Location → Size → Service → Checkout → Details → Confirm.
  useEffect(() => {
    const plan = (membershipParam || "").toLowerCase();
    if (plan === "monthly" || plan === "biweekly" || plan === "weekly") {
      updateBookingData({ membershipPlan: plan, serviceType: "standard" });
    }
    if (homeSizeParam) {
      updateBookingData({ homeSizeId: homeSizeParam });
    }
    if (welcomeCode && /^WELCOME-[A-Z0-9]+$/i.test(welcomeCode)) {
      updateBookingData({ promoCode: welcomeCode.toUpperCase() });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [membershipParam, homeSizeParam]);
  
  const [zipCode, setZipCode] = useState("");
  const [isValidating, setIsValidating] = useState(false);
  const [formMode, setFormMode] = useState<FormMode>('zip');
  const [cityState, setCityState] = useState("");
  
  // Contact form state
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleZipSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (zipCode.length !== 5) return;
    
    setIsValidating(true);
    
    // Check if ZIP is in service coverage
    const { data: coverage } = await supabase
      .from('service_coverage_zones')
      .select('city, state')
      .eq('zip_code', zipCode)
      .eq('is_active', true)
      .single();
    
    setIsValidating(false);

    // --- Track ZIP submission in database (fire-and-forget) ---
    const placeholderEmail = `anonymous-${crypto.randomUUID()}@placeholder`;

    // Insert into abandoned_carts
    Promise.resolve(
      supabase
        .from('abandoned_carts')
        .insert({ email: placeholderEmail, zip_code: zipCode, last_step: 'zip' })
        .select('id')
        .single()
    ).then(({ data }) => {
      if (data?.id) {
        localStorage.setItem('abandoned_cart_id', data.id);
        localStorage.setItem('abandoned_cart_email', placeholderEmail);
      }
    }).catch(err => console.error('Abandoned cart insert error:', err));

    // Insert into leads
    Promise.resolve(
      supabase
        .from('leads')
        .insert({
          first_name: 'Anonymous',
          last_name: 'Visitor',
          zip_code: zipCode,
          status: 'zip_only',
          source: 'Website',
          channel: 'Website',
        })
    ).then(({ error }) => { if (error) console.error('Lead insert error:', error); })
      .catch(err => console.error('Lead insert error:', err));

    if (coverage) {
      // ZIP is in service area - show contact form
      setCityState(`${coverage.city}, ${coverage.state}`);
      setFormMode('contact');
      // Persist ZIP + the resolved city/state into the booking context so
      // downstream pages (Details, Checkout, GHL sync) inherit them
      // automatically — no more empty City/State in GHL when the
      // customer drops off before the Details page.
      updateBookingData({
        zipCode,
        city: coverage.city,
        state: coverage.state,
      });

      // Fire Meta Pixel Lead event for in-area ZIPs
      trackLead(zipCode);
    } else {
      // ZIP is NOT in service area - show waitlist form
      setCityState("");
      setFormMode('waitlist');
    }
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName || !lastName || !email || !phone) return;
    
    setIsSubmitting(true);
    
    const formattedPhone = phone.replace(/\D/g, '');
    
    // Update booking data
    updateBookingData({
      firstName,
      lastName,
      email,
      phone: formattedPhone,
    });
    
    // Update existing abandoned_cart row (or create new one)
    const existingCartId = localStorage.getItem('abandoned_cart_id');
    const existingCartEmail = localStorage.getItem('abandoned_cart_email');
    
    // Tracking bag — pulled once and reused for the cart-row stamp,
    // the lead-capture webhook, and any downstream calls in this
    // submit handler.
    const tracking = getStoredTrackingData();
    const trackingPayload = getTrackingPayload();

    if (existingCartId && existingCartEmail) {
      // Update the placeholder row with real contact info + attribution
      supabase
        .from('abandoned_carts')
        .update({
          email,
          first_name: firstName,
          last_name: lastName,
          phone: formattedPhone,
          last_step: 'contact',
          tracking: trackingPayload,
          utm_source: tracking.utm_source,
          utm_medium: tracking.utm_medium,
          utm_campaign: tracking.utm_campaign,
          utm_content: tracking.utm_content,
          utm_term: tracking.utm_term,
          landing_page: tracking.landing_page,
          referrer: tracking.referrer,
          fbclid: tracking.fbclid,
          gclid: tracking.gclid,
          first_visit_at: tracking.first_visit_timestamp,
        })
        .eq('id', existingCartId)
        .then(({ error }) => { if (error) console.error('Cart update error:', error); });

      // Clean up localStorage placeholder
      localStorage.removeItem('abandoned_cart_email');
    } else {
      // Fallback: create via edge function if no existing cart
      supabase.functions.invoke('track-abandoned-cart', {
        body: {
          email,
          firstName,
          lastName,
          phone: formattedPhone,
          zipCode,
          lastStep: 'contact',
          tracking: trackingPayload,
        }
      }).catch(err => console.error('Track cart error:', err));
    }
    
    // (tracking + trackingPayload already pulled above; reused here.)

    // Send lead capture webhook with client-side duplicate guard
    const capturedEmails: string[] = JSON.parse(localStorage.getItem('lead_captured_emails') || '[]');
    if (!capturedEmails.includes(email.toLowerCase())) {
      supabase.functions.invoke('send-lead-capture-webhook', {
        body: {
          firstName,
          lastName,
          email,
          phone: formattedPhone,
          zipCode,
          city: cityState.split(', ')[0] || '',
          state: cityState.split(', ')[1] || '',
          source: tracking.utm_source || 'Website',
          landingPage: tracking.landing_page || '/book/zip',
          referrer: tracking.referrer || undefined,
          fbclid: tracking.fbclid || fbclid || undefined,
          gclid: tracking.gclid || undefined,
          firstVisitTimestamp: tracking.first_visit_timestamp || undefined,
          utmSource: tracking.utm_source || undefined,
          utmMedium: tracking.utm_medium || undefined,
          utmCampaign: tracking.utm_campaign || undefined,
          utmContent: tracking.utm_content || undefined,
          utmTerm: tracking.utm_term || undefined,
          tracking: trackingPayload,
        }
      }).then(() => {
        const updated = [...capturedEmails, email.toLowerCase()];
        localStorage.setItem('lead_captured_emails', JSON.stringify(updated));
      }).catch(err => console.error('Lead webhook error:', err));
    }
    
    router.push("/book/sqft");
  };

  const handleWaitlistSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firstName || !lastName || !email || !phone) return;
    
    setIsSubmitting(true);
    
    const formattedPhone = phone.replace(/\D/g, '');
    
    try {
      const trackingPayload = getTrackingPayload();
      const tracking = getStoredTrackingData();
      const { error } = await supabase.functions.invoke('add-to-waitlist', {
        body: {
          email,
          firstName,
          lastName,
          phone: formattedPhone,
          zipCode,
          source: tracking.utm_source || 'website',
          landingPage: tracking.landing_page || undefined,
          referrer: tracking.referrer || undefined,
          utmSource: tracking.utm_source || undefined,
          utmMedium: tracking.utm_medium || undefined,
          utmCampaign: tracking.utm_campaign || undefined,
          utmContent: tracking.utm_content || undefined,
          utmTerm: tracking.utm_term || undefined,
          fbclid: tracking.fbclid || undefined,
          gclid: tracking.gclid || undefined,
          firstVisitTimestamp: tracking.first_visit_timestamp || undefined,
          tracking: trackingPayload,
        }
      });
      
      if (error) {
        console.error('Waitlist error:', error);
      }
      
      setFormMode('waitlist-success');
    } catch (err) {
      console.error('Waitlist submission error:', err);
      setFormMode('waitlist-success'); // Still show success to user
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChangeZip = () => {
    setFormMode('zip');
    setZipCode("");
    setFirstName("");
    setLastName("");
    setEmail("");
    setPhone("");
    setCityState("");
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhoneNumber(e.target.value);
    setPhone(formatted);
  };

  return (
    <div className="min-h-screen bg-gradient-hero">
      <SEO title="Book a Cleaning" description="Enter your ZIP code to check if Novara Cleaning serves your area. Professional home cleaning starting at $99." />
      {/* Sticky Booking Header */}
      <BookingHeader currentStep={1} totalSteps={6} stepLabel="Location" />

      {/* Hero + Booking Section */}
      <section className="container mx-auto px-4 py-12 md:py-20">
        <div className="max-w-2xl mx-auto text-center space-y-8">
          
          {/* Referral Banner */}
          {referralCode && (
            <div className="flex items-center gap-3 p-4 bg-primary/10 border border-primary/30 rounded-xl animate-fade-in">
              <div className="flex-shrink-0 w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
                <RiGiftLine className="w-5 h-5 text-primary" />
              </div>
              <div className="text-left">
                <p className="font-semibold text-foreground text-sm">You were referred! 🎉</p>
                <p className="text-xs text-muted-foreground">25% off your first cleaning is waiting for you.</p>
              </div>
            </div>
          )}

          <div className="space-y-4">
            <h1 className="text-3xl md:text-4xl tracking-tight lg:text-6xl text-center font-extrabold font-jakarta mx-auto max-w-4xl">
              {formMode === 'waitlist-success'
                ? "You're On The List! 🎉"
                : "Book Your Cleaning Today"}
            </h1>

            {/* New-customer 50% off sub-headline — sits directly under
                the page headline, in our primary brand color. Hidden on
                the waitlist-success state. */}
            {formMode !== 'waitlist-success' && (
              <p className="mx-auto max-w-xl text-sm leading-relaxed text-[#2c2c2c] md:text-base">
                <span className="font-jakarta text-lg font-bold text-foreground md:text-2xl">
                  <span className="bg-gradient-primary bg-clip-text text-transparent">Standard 15% off. Deep 25% off.</span>
                </span>{" "}
                {formMode === 'waitlist'
                  ? "We are not in your area yet, and we are expanding soon."
                  : "Enter your ZIP code and we will show the price for your home. Most bookings take a 50% deposit."}
              </p>
            )}
          </div>

          {/* Main Card */}
          <Card className="overflow-hidden">
            <CardContent className="pt-8 pb-8 space-y-6">
              
              {/* ZIP Code Form */}
              {formMode === 'zip' && (
                <form onSubmit={handleZipSubmit} className="space-y-4 animate-fade-in">
                  <div className="space-y-2">
                    <label htmlFor="zipCode" className="text-sm font-medium text-left block">
                      Enter Your ZIP Code
                    </label>
                    <Input 
                      id="zipCode" 
                      type="text" 
                      inputMode="numeric" 
                      pattern="[0-9]*" 
                      maxLength={5} 
                      placeholder="12345" 
                      value={zipCode} 
                      onChange={e => setZipCode(e.target.value.replace(/\D/g, ''))} 
                      className="h-14 text-lg text-center" 
                      autoFocus 
                    />
                    <p className="text-xs text-muted-foreground">
                      We'll check if we service your area
                    </p>
                  </div>

                  <Button 
                    type="submit" 
                    size="lg" 
                    disabled={zipCode.length !== 5 || isValidating} 
                    className="w-full h-12 md:h-14 text-base md:text-lg font-semibold"
                  >
                    {isValidating ? "Checking..." : "Continue"}
                    <RiArrowRightLine className="w-4 h-4 md:w-5 md:h-5 ml-2" />
                  </Button>
                </form>
              )}

              {/* Contact Details Form (Service Area) */}
              {formMode === 'contact' && (
                <form onSubmit={handleContactSubmit} className="space-y-5 animate-fade-in">
                  {/* Success Message */}
                  <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
                    <RiCheckboxCircleLine className="w-6 h-6 text-primary flex-shrink-0 mt-0.5" />
                    <div className="text-left">
                      <p className="font-semibold text-foreground">
                        Great news! We service {cityState}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Enter your details and we will show the price for your home.
                      </p>
                    </div>
                  </div>

                  {/* Name Fields */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="firstName" className="text-sm font-medium text-left block">
                        First Name
                      </label>
                      <Input
                        id="firstName"
                        type="text"
                        placeholder="John"
                        value={firstName}
                        onChange={e => setFirstName(e.target.value)}
                        className="h-12"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="lastName" className="text-sm font-medium text-left block">
                        Last Name
                      </label>
                      <Input
                        id="lastName"
                        type="text"
                        placeholder="Smith"
                        value={lastName}
                        onChange={e => setLastName(e.target.value)}
                        className="h-12"
                        required
                      />
                    </div>
                  </div>

                  {/* Email Field */}
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-left block">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="john@example.com"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      className="h-12"
                      required
                    />
                  </div>

                  {/* Phone Field */}
                  <div className="space-y-2">
                    <label htmlFor="phone" className="text-sm font-medium text-left block">
                      Phone Number
                    </label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="(301) 555-0123"
                      value={phone}
                      onChange={handlePhoneChange}
                      className="h-12"
                      required
                    />
                  </div>

                  {/* Submit Button */}
                  <Button 
                    type="submit" 
                    size="lg" 
                    disabled={!firstName || !lastName || !email || phone.replace(/\D/g, '').length !== 10 || isSubmitting} 
                    className="w-full h-12 md:h-14 text-base md:text-lg font-semibold"
                  >
                    {isSubmitting ? "Processing..." : "Claim My Discount →"}
                  </Button>

                  {/* Change ZIP Link */}
                  <button
                    type="button"
                    onClick={handleChangeZip}
                    className="text-sm text-primary hover:text-primary-hover underline underline-offset-2"
                  >
                    ← Change ZIP code ({zipCode})
                  </button>
                </form>
              )}

              {/* Waitlist Form (Outside Service Area) */}
              {formMode === 'waitlist' && (
                <form onSubmit={handleWaitlistSubmit} className="space-y-5 animate-fade-in">
                  {/* Info Message */}
                  <div className="flex items-start gap-3 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <RiMapPinLine className="w-6 h-6 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="text-left">
                      <p className="font-semibold text-amber-800">
                        We're not in {zipCode} yet
                      </p>
                      <p className="text-sm text-amber-700">
                        But we're expanding to your area soon! Join our waitlist and be the first to know.
                      </p>
                    </div>
                  </div>

                  {/* Benefits */}
                  <div className="bg-muted/30 rounded-lg p-4 space-y-2">
                    <p className="text-sm font-medium text-foreground">Waitlist perks:</p>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li className="flex items-center gap-2">
                        <RiCheckboxCircleLine className="w-4 h-4 text-primary" />
                        First to know when we launch in your area
                      </li>
                      <li className="flex items-center gap-2">
                        <RiCheckboxCircleLine className="w-4 h-4 text-primary" />
                        Exclusive early-bird pricing
                      </li>
                      <li className="flex items-center gap-2">
                        <RiCheckboxCircleLine className="w-4 h-4 text-primary" />
                        Special founding member perks
                      </li>
                    </ul>
                  </div>

                  {/* Name Fields */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="firstName" className="text-sm font-medium text-left block">
                        First Name
                      </label>
                      <Input
                        id="firstName"
                        type="text"
                        placeholder="John"
                        value={firstName}
                        onChange={e => setFirstName(e.target.value)}
                        className="h-12"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="lastName" className="text-sm font-medium text-left block">
                        Last Name
                      </label>
                      <Input
                        id="lastName"
                        type="text"
                        placeholder="Smith"
                        value={lastName}
                        onChange={e => setLastName(e.target.value)}
                        className="h-12"
                        required
                      />
                    </div>
                  </div>

                  {/* Email Field */}
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-left block">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="john@example.com"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      className="h-12"
                      required
                    />
                  </div>

                  {/* Phone Field */}
                  <div className="space-y-2">
                    <label htmlFor="phone" className="text-sm font-medium text-left block">
                      Phone Number
                    </label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="(301) 555-0123"
                      value={phone}
                      onChange={handlePhoneChange}
                      className="h-12"
                      required
                    />
                  </div>

                  {/* Submit Button */}
                  <Button 
                    type="submit" 
                    size="lg" 
                    disabled={!firstName || !lastName || !email || phone.replace(/\D/g, '').length !== 10 || isSubmitting} 
                    className="w-full h-12 md:h-14 text-base md:text-lg font-semibold"
                  >
                    {isSubmitting ? "Adding to Waitlist..." : "Join the Waitlist"}
                    <RiTimeLine className="w-4 h-4 md:w-5 md:h-5 ml-2" />
                  </Button>

                  {/* Change ZIP Link */}
                  <button
                    type="button"
                    onClick={handleChangeZip}
                    className="text-sm text-primary hover:text-primary-hover underline underline-offset-2"
                  >
                    ← Try a different ZIP code
                  </button>
                </form>
              )}

              {/* Waitlist Success */}
              {formMode === 'waitlist-success' && (
                <div className="space-y-6 animate-fade-in text-center py-4">
                  <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                    <RiCheckboxCircleLine className="w-10 h-10 text-primary" />
                  </div>
                  
                  <div className="space-y-2">
                    <h2 className="text-xl font-semibold text-foreground">
                      Thanks for joining, {firstName}!
                    </h2>
                    <p className="text-muted-foreground">
                      We've added you to our waitlist for ZIP code {zipCode}. 
                      You'll be the first to know when we start servicing your area.
                    </p>
                  </div>

                  <div className="bg-muted/50 rounded-lg p-4 text-sm text-muted-foreground">
                    <p>📧 Check your email for a confirmation</p>
                    <p className="mt-1">We'll reach out in the coming months!</p>
                  </div>

                  <Button 
                    onClick={handleChangeZip}
                    variant="outline"
                    className="mt-4"
                  >
                    Check Another ZIP Code
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Membership Promo Card - Only show when not on waitlist success */}
          {formMode !== 'waitlist-success' && (
            <Card className="mt-12 border-2 border-primary/40 bg-gradient-lavender shadow-card">
              <CardContent className="pt-6 pb-6">
                <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 md:w-16 md:h-16 bg-primary rounded-full flex items-center justify-center shadow-lavender">
                      <RiVipCrownLine className="w-6 h-6 md:w-8 md:h-8 text-white" />
                    </div>
                  </div>
                  <div className="flex-1 text-center md:text-left space-y-2">
                    <h3 className="text-lg md:text-xl font-semibold">Join Our Membership Program</h3>
                    <p className="text-sm md:text-base text-muted-foreground">
                      Get priority booking, exclusive discounts up to 30%, and credits that never expire. 
                      Perfect for regular cleaning schedules.
                    </p>
                  </div>
                  <Button onClick={() => router.push("/membership")} size="lg" className="bg-primary hover:bg-primary-hover w-full md:w-auto h-11 md:h-12">
                    Learn More
                    <RiArrowRightLine className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </section>

      <ZipGallery />

      {/* Footer */}
      <BookingFooter />
    </div>
  );
}
